﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Read_Write_From_txt
{
    public partial class Update_win : Form
    {
        string path = @"../../file1.txt";

        public Update_win()
        {
            InitializeComponent();
        }

        private void updateTeam_TextChanged(object sender, EventArgs e)
        {

        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            bool flag = false;
            string oldLine;
            string newStr = "";
            StreamReader sr = File.OpenText(path);
            while ((oldLine = sr.ReadLine()) != null)
            {
                if (!oldLine.Contains(updateTeam.Text))
                {
                    newStr += oldLine + Environment.NewLine;
                }
                else
                {
                    if (input_name.Text == "")
                    {
                        newStr += oldLine + Environment.NewLine;
                    }
                    else
                    {
                        if (input_win.Value == 0)
                        {
                            newStr += oldLine + Environment.NewLine;
                        }
                        newStr += oldLine = "Team Name: " + input_name.Text + Environment.NewLine;
                        flag = true;
                    }
                }
            }
            sr.Close();
            File.WriteAllText(path, newStr);
        }
    }
}
